//g++ -std=c++20 -o runProgram a3/a31.cpp


// #include <iostream>
// #include <vector>
// #include <chrono>

// template <typename T>
// std::vector<T*> find_all(std::vector<T>& vec, bool (*criterion)(T)) {
//     std::vector<T*> result;
//     for (auto& elem : vec) {
//         if (criterion(elem)) {
//             result.push_back(&elem);
//         }
//     }
//     return result;
// }

// bool isEven(int i) {
//     return i % 2 == 0;
// }

// // Try the algorithm with a vector of ints

// int main() {
//     std::vector<int> vec = { 1, 2, 3, 4, 5, 6, 7, 8 };
//     std::vector<int*> result = find_all(vec, isEven);

//     for (auto ptr : result) {
//         std::cout << *ptr << " ";
//     }
//     std::cout << std::endl;

//     return 0;
// }


#include <iostream>
#include <vector>
#include <chrono>

template <typename T>
std::vector<T*> find_all(const std::vector<T>& data, T threshold) {
    std::vector<T*> result;

    for (size_t i = 0; i < data.size(); ++i) {
        if (data[i] > threshold) {
            result.push_back(&data[i]);
        }
    }

    return result;
}

int main() {
    // Generate sample data (10000000 integers ranging from 1 to 100)
    const int dataSize = 10000000;
    std::vector<int> data(dataSize);
    for (int i = 0; i < dataSize; ++i) {
        data[i] = rand() % 100 + 1;
    }

    // Define the threshold for filtering
    int threshold = 70;

    // Measure the performance
    auto startTime = std::chrono::high_resolution_clock::now();
    std::vector<int*> result = find_all(data, threshold);
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime).count();

    // Output the result and performance
    std::cout << "Number of elements meeting the criteria: " << result.size() << std::endl;
    std::cout << "Execution time: " << duration << " milliseconds" << std::endl;

    return 0;
}
