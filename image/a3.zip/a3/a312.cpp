//g++ -std=c++20 -o runProgram a3/a312.cpp

#include <iostream>
#include <vector>
#include <chrono>

template <typename T>
std::vector<T*> find_all(const std::vector<T>& data, size_t threshold) {
    std::vector<T*> result;

    for (size_t i = 0; i < data.size(); ++i) {
        if (data[i].length() > threshold) {
            result.push_back(const_cast<T*>(&data[i]));
        }
    }

    return result;
}

int main() {
    // Generate a large sample data vector of strings
    const size_t dataSize = 1000000;
    std::vector<std::string> data;
    data.reserve(dataSize);
    for (size_t i = 0; i < dataSize; ++i) {
        data.emplace_back("string_" + std::to_string(i));
    }

    // Define the threshold for filtering (e.g., strings longer than 8 characters)
    size_t threshold = 8;

    // Measure the performance
    auto startTime = std::chrono::high_resolution_clock::now();
    std::vector<std::string*> result = find_all(data, threshold);
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime).count();

    // Output the result and performance
    std::cout << "Number of elements meeting the criteria: " << result.size() << std::endl;
    std::cout << "Execution time: " << duration << " microseconds" << std::endl;

    return 0;
}
