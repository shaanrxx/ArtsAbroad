//g++ -std=c++20 -o runProgram a3/a322.cpp

#include <iostream>
#include <vector>
#include <algorithm>
#include <future>
#include <chrono>
#include <random>
#include <queue>
#include <mutex>
#include <condition_variable>

std::string generate_random_string(int length) {
    static const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static std::mt19937 generator(std::random_device{}());
    static std::uniform_int_distribution<> distribution(0, sizeof(charset) - 2);

    std::string result;
    for (int i = 0; i < length; ++i) {
        result += charset[distribution(generator)];
    }
    return result;
}

template <typename T>
std::vector<T*> find_all_worker(const std::vector<T>& data, T threshold, size_t start, size_t end,
                                std::queue<std::vector<T*>>& resultQueue, std::mutex& mutex, std::condition_variable& cv) {
    std::vector<T*> result;

    for (size_t i = start; i < end; ++i) {
        if (data[i] > threshold) {
            result.push_back(const_cast<T*>(&data[i]));
        }
    }

    // Send the result to the queue
    {
        std::unique_lock<std::mutex> lock(mutex);
        resultQueue.push(result);
    }
    cv.notify_one();

    return result;
}

template <typename T>
std::vector<T*> find_all_parallel(const std::vector<T>& data, T threshold, int num_threads) {
    std::vector<std::future<std::vector<T*>>> futures;

    // Synchronized queue to store results from worker threads
    std::queue<std::vector<T*>> resultQueue;
    std::mutex mutex;
    std::condition_variable cv;

    size_t chunk_size = data.size() / num_threads;
    size_t start = 0;
    size_t end = chunk_size;

    for (int i = 0; i < num_threads; ++i) {
        if (i == num_threads - 1) {
            end = data.size(); // Handle last chunk with the remaining elements
        }

        futures.push_back(std::async(std::launch::async, find_all_worker<T>, std::cref(data), threshold, start, end,
                                     std::ref(resultQueue), std::ref(mutex), std::ref(cv)));
        start = end;
        end += chunk_size;
    }

    std::vector<T*> final_result;

    // Wait for all threads to complete and collect results
    for (int i = 0; i < num_threads; ++i) {
        std::vector<T*> thread_result;
        {
            std::unique_lock<std::mutex> lock(mutex);
            cv.wait(lock, [&resultQueue] { return !resultQueue.empty(); });
            thread_result = std::move(resultQueue.front());
            resultQueue.pop();
        }
        final_result.insert(final_result.end(), thread_result.begin(), thread_result.end());
    }

    return final_result;
}

int main() {

    std::mt19937 generator(10); // Use any constant value as the seed (e.g., 42)
    // Generate a vector of 1,000,000 random 20-letter strings
    const int dataSize = 1000000;
    const int stringLength = 20;
    std::vector<std::string> data;
    data.reserve(dataSize);
    for (int i = 0; i < dataSize; ++i) {
        data.push_back(generate_random_string(stringLength));
    }

    // Define the threshold for filtering
    std::string threshold = "xxxxxxxxxxxxxxxxxxxx"; // Replace with the desired threshold string

    // Number of threads to use
    int num_threads = 10;

    // Set up the threads and data structures before starting the timer
    std::vector<std::future<std::vector<std::string*>>> futures;
    std::queue<std::vector<std::string*>> resultQueue;
    std::mutex mutex;
    std::condition_variable cv;
    size_t chunk_size = data.size() / num_threads;
    size_t start = 0;
    size_t end = chunk_size;
    for (int i = 0; i < num_threads; ++i) {
        if (i == num_threads - 1) {
            end = data.size(); // Handle last chunk with the remaining elements
        }
        futures.push_back(std::async(std::launch::async, find_all_worker<std::string>,
                                     std::cref(data), threshold, start, end,
                                     std::ref(resultQueue), std::ref(mutex), std::ref(cv)));
        start = end;
        end += chunk_size;
    }

    // Start the timer just before waiting for the threads to complete
    auto startTime = std::chrono::high_resolution_clock::now();

    // Wait for all threads to complete and collect results
    std::vector<std::string*> final_result;
    for (int i = 0; i < num_threads; ++i) {
        std::vector<std::string*> thread_result;
        {
            std::unique_lock<std::mutex> lock(mutex);
            cv.wait(lock, [&resultQueue] { return !resultQueue.empty(); });
            thread_result = std::move(resultQueue.front());
            resultQueue.pop();
        }
        final_result.insert(final_result.end(), thread_result.begin(), thread_result.end());
    }

    // Stop the timer after the threads have completed their work
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime).count();

    // Output the result and performance
    std::cout << "Number of elements meeting the criteria: " << final_result.size() << std::endl;
    std::cout << "Execution time (excluding thread creation): " << duration << " microseconds" << std::endl;

    return 0;
}