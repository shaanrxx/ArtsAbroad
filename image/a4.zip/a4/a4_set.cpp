//g++ -std=c++20 -o runProgram a4/a4_set.cpp


#include <iostream>
#include <list>
#include <vector>
#include <set>
#include <algorithm>
#include <random>
#include <chrono>

using namespace std;

// Function to perform insertion sort and insert the element in the correct position
template <typename T>
void insertion_sort(T& container, int num) {
    auto it = container.begin();
    while (it != container.end() && *it < num) {
        ++it;
    }
    container.insert(it, num);
}

// Function to remove an element from the container at the specified position
template <typename T>
void remove_element(T& container, int position) {
    auto it = container.begin();
    advance(it, position);
    container.erase(it);
}

// Function to generate N random integers without replacement
vector<int> generate_random_integers(int N) {
    vector<int> nums(N);
    for (int i = 0; i < N; ++i) {
        nums[i] = i + 1;
    }
    unsigned seed = chrono::system_clock::now().time_since_epoch().count();
    shuffle(nums.begin(), nums.end(), default_random_engine(seed));
    return nums;
}

int main() {
    int N = 100000; // The number of random integers to generate and insert
    auto nums = generate_random_integers(N);

    // Record the start time for insertion
    auto start_insertion = chrono::high_resolution_clock::now();

    // Experiment with std::set
    set<int> sequence_set;
    for (int num : nums) {
        sequence_set.insert(num);
    }

    // Record the end time for insertion
    auto end_insertion = chrono::high_resolution_clock::now();

    // Record the start time for removal
    auto start_removal = chrono::high_resolution_clock::now();

    // Remove elements from the sequence at random positions
    for (int i = 0; i < N; ++i) {
        int position = rand() % sequence_set.size();
        remove_element(sequence_set, position);
    }

    // Record the end time for removal
    auto end_removal = chrono::high_resolution_clock::now();

    // Calculate and print the time taken for insertion and removal
    auto insertion_time = chrono::duration_cast<chrono::milliseconds>(end_insertion - start_insertion).count();
    auto removal_time = chrono::duration_cast<chrono::milliseconds>(end_removal - start_removal).count();

    cout << "Insertion time: " << insertion_time << " milliseconds" << endl;
    cout << "Removal time: " << removal_time << " milliseconds" << endl;

    return 0;
}













// #include <iostream>
// #include <set>
// #include <algorithm>
// #include <random>
// #include <chrono>

// using namespace std;

// // Function to generate N distinct random integers without replacement
// set<int> generate_distinct_random_integers(int N) {
//     set<int> nums;
//     for (int i = 1; i <= N; ++i) {
//         nums.insert(i);
//     }
//     unsigned seed = chrono::system_clock::now().time_since_epoch().count();
//     shuffle(nums.begin(), nums.end(), default_random_engine(seed)); // set does not have begin() and end() for iterators, so this line will throw an error.
//     return nums;
// }

// // Function to print the elements of a set
// void print_set(const set<int>& s) {
//     for (const auto& num : s) {
//         cout << num << " ";
//     }
//     cout << endl;
// }

// int main() {
//     int N = 10; // The number of random integers to generate
//     int num_experiments = 3; // Number of experiments with different random seeds

//     for (int experiment = 1; experiment <= num_experiments; ++experiment) {
//         cout << "Experiment " << experiment << ":" << endl;
//         auto nums = generate_distinct_random_integers(N);

//         set<int> sequence;

//         for (int num : nums) {
//             sequence.insert(num);
//             print_set(sequence);
//         }
//     }

//     return 0;
// }


