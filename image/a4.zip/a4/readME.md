
747993

Shaan Rehsi

Device Specs: 
Processor: Intel(R) Core(TM) i7-10750H CPU @ 2.60GHz   2.59 GHz
Installed RAM: 16,0 GB (15,7 GB usable)
System type: 64-bit operating system, x64-based processor
OS build: 22621.1992
Compiler: GCC


