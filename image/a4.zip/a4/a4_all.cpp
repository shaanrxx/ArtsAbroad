//g++ -std=c++20 -o runProgram a4_all.cpp


#include <iostream>
#include <list>
#include <vector>
#include <set>
#include <algorithm>
#include <random>
#include <chrono>

using namespace std;

// Function to perform insertion sort and insert the element in the correct position
template <typename T>
void insertion_sort(T& container, int num) {
    auto it = container.begin();
    while (it != container.end() && *it < num) {
        ++it;
    }
    container.insert(it, num);
}

// Function to remove an element from the container at the specified position
template <typename T>
void remove_element(T& container, int position) {
    auto it = container.begin();
    advance(it, position);
    container.erase(it);
}

// Function to generate N random integers without replacement
vector<int> generate_random_integers(int N) {
    vector<int> nums(N);
    for (int i = 0; i < N; ++i) {
        nums[i] = i + 1;
    }
    unsigned seed = chrono::system_clock::now().time_since_epoch().count();
    shuffle(nums.begin(), nums.end(), default_random_engine(seed));
    return nums;
}

// Function to print the elements of the container
template <typename T>
void print_container(const T& container) {
    for (const auto& num : container) {
        cout << num << " ";
    }
    cout << endl;
}

int main() {
    int N = 4; // The number of random integers to generate and insert
    auto nums = generate_random_integers(N);

    // Experiment with std::list
    list<int> sequence_list;
    for (int num : nums) {
        insertion_sort(sequence_list, num);
        print_container(sequence_list);
    }

    // Experiment with std::vector
    vector<int> sequence_vector;
    for (int num : nums) {
        insertion_sort(sequence_vector, num);
        print_container(sequence_vector);
    }

    // Experiment with std::set
    set<int> sequence_set;
    for (int num : nums) {
        sequence_set.insert(num);
        print_container(sequence_set);
    }

    // Remove elements from the sequence at random positions
    for (int i = 0; i < N; ++i) {
        int position = rand() % sequence_list.size();
        remove_element(sequence_list, position);
        print_container(sequence_list);
    }

    return 0;
}
