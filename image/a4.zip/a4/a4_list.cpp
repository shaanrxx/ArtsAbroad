//g++ -std=c++20 -o runProgram a4/a4_list.cpp

//g++ -std=c++20 -o runProgram a4_all.cpp


#include <iostream>
#include <list>
#include <algorithm>
#include <random>
#include <chrono>
#include <fstream>

using namespace std;

// Function to perform insertion sort and insert the element in the correct position
template <typename T>
void insertion_sort(T& container, int num) {
    auto it = container.begin();
    while (it != container.end() && *it < num) {
        ++it;
    }
    container.insert(it, num);
}

// Function to remove an element from the container at the specified position
template <typename T>
void remove_element(T& container, int position) {
    auto it = container.begin();
    advance(it, position);
    container.erase(it);
}

// Function to generate N random integers without replacement
vector<int> generate_random_integers(int N) {
    vector<int> nums(N);
    for (int i = 0; i < N; ++i) {
        nums[i] = i + 1;
    }
    unsigned seed = chrono::system_clock::now().time_since_epoch().count();
    shuffle(nums.begin(), nums.end(), default_random_engine(seed));
    return nums;
}

int main() {
    int N = 300000; // The number of random integers to generate and insert
    auto nums = generate_random_integers(N);

    // Record the start time for insertion
    auto start_insertion = chrono::high_resolution_clock::now();

    // Experiment with std::list
    list<int> sequence_list;
    for (int num : nums) {
        insertion_sort(sequence_list, num);
    }

    // Record the end time for insertion
    auto end_insertion = chrono::high_resolution_clock::now();

    // Record the start time for removal
    auto start_removal = chrono::high_resolution_clock::now();

    // Remove elements from the list at random positions
    for (int i = 0; i < N; ++i) {
        int position = rand() % sequence_list.size();
        remove_element(sequence_list, position);
    }

    // Record the end time for removal
    auto end_removal = chrono::high_resolution_clock::now();

    // Calculate and print the time taken for insertion and removal
    auto insertion_time = chrono::duration_cast<chrono::milliseconds>(end_insertion - start_insertion).count();
    auto removal_time = chrono::duration_cast<chrono::milliseconds>(end_removal - start_removal).count();

    cout << "Insertion time: " << insertion_time << " milliseconds" << endl;
    cout << "Removal time: " << removal_time << " milliseconds" << endl;


        // Create and open a data file for writing
    ofstream dataFile("timings.dat");

    // Write the header line to the data file
    dataFile << "Size InsertionTime RemovalTime" << endl;

    // Perform the experiments for different sizes
    for (int N = 10000; N <= 100000; N += 10000) {
        // ... (existing code for insertion and removal)

        // Write the measured times to the data file
        dataFile << N << " " << insertion_time << " " << removal_time << endl;
    }

    // Close the data file
    dataFile.close();

    return 0;
}




// g++ -std=c++20 -o runProgram a4/a4_list.cpp

// #include <iostream>
// #include <list>
// #include <algorithm>
// #include <random>
// #include <chrono>

// using namespace std;

// // Function to generate N random integers without replacement
// list<int> generate_random_integers(int N) {
//     list<int> nums;
//     for (int i = 1; i <= N; ++i) {
//         nums.push_back(i);
//     }
//     unsigned seed = chrono::system_clock::now().time_since_epoch().count();
//     shuffle(nums.begin(), nums.end(), default_random_engine(seed));
//     return nums;
// }

// // Function to insert an element in its proper position in a sequence (insertion sort)
// void insert_in_sequence(list<int>& sequence, int num) {
//     auto it = lower_bound(sequence.begin(), sequence.end(), num);
//     sequence.insert(it, num);
// }

// // Function to print the elements of a list
// void print_list(const list<int>& lst) {
//     for (const auto& num : lst) {
//         cout << num << " ";
//     }
//     cout << endl;
// }

// int main() {
//     int N = 4; // The number of random integers to generate
//     auto nums = generate_random_integers(N);

//     list<int> sequence;
//     for (int num : nums) {
//         insert_in_sequence(sequence, num);
//         print_list(sequence);
//     }

//     return 0;
// }
