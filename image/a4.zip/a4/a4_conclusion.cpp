//g++ -std=c++20 -o runProgram a4/a4_conclusion.cpp


#include <iostream>
#include <list>
#include <vector>
#include <set>
#include <algorithm>
#include <random>
#include <chrono>

using namespace std;

struct LargeStruct {
    int value;
    // other members of LargeStruct

    // Define the less-than operator for LargeStruct
    bool operator<(const LargeStruct& other) const {
        return value < other.value;
    }
};

// Custom comparator function to sort elements in the set
struct CustomComparator {
    bool operator()(const LargeStruct& a, const LargeStruct& b) const {
        return a.value < b.value;
    }
};

// Function to generate N random integers without replacement
vector<LargeStruct> generate_random_integers(int N) {
    vector<LargeStruct> nums(N);
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < 100; ++j) {
            nums[i].value = i * 100 + j + 1;
        }
    }
    unsigned seed = chrono::system_clock::now().time_since_epoch().count();
    shuffle(nums.begin(), nums.end(), default_random_engine(seed));
    return nums;
}

int main() {
    int N = 300000; // The number of random integers to generate and insert
    auto nums = generate_random_integers(N);

    // Record the start time for insertion
    auto start_insertion = chrono::high_resolution_clock::now();

    // Experiment with std::set
    set<LargeStruct, CustomComparator> sequence_set;

    // Insert elements into the set
    for (const auto& item : nums) {
        sequence_set.insert(item);
    }

    // Record the end time for insertion
    auto end_insertion = chrono::high_resolution_clock::now();

    // Record the start time for removal
    auto start_removal = chrono::high_resolution_clock::now();

    // Remove elements from the set at random positions
    for (int i = 0; i < N; ++i) {
        if (!sequence_set.empty()) {
            int position = rand() % sequence_set.size();
            auto it = sequence_set.begin();
            advance(it, position);
            sequence_set.erase(it);
        }
    }

    // Record the end time for removal
    auto end_removal = chrono::high_resolution_clock::now();

    // Calculate and print the time taken for insertion and removal
    auto insertion_time_set = chrono::duration_cast<chrono::milliseconds>(end_insertion - start_insertion).count();
    auto removal_time_set = chrono::duration_cast<chrono::milliseconds>(end_removal - start_removal).count();

    cout << "Set Insertion time: " << insertion_time_set << " milliseconds" << endl;
    cout << "Set Removal time: " << removal_time_set << " milliseconds" << endl;

    // ... (continue with std::vector and std::list as before)

    return 0;
}



// #include <iostream>
// #include <list>
// #include <vector>
// #include <set>
// #include <algorithm>
// #include <random>
// #include <chrono>

// using namespace std;

// struct LargeStruct {
//     int value;
//     // other members of LargeStruct

//     // Define the less-than operator for LargeStruct
//     bool operator<(const LargeStruct& other) const {
//         return value < other.value;
//     }
// };

// // Function to perform insertion sort and insert the element in the correct position
// template <typename T>
// void insertion_sort(T& container, const LargeStruct& item) {
//     container.insert(lower_bound(container.begin(), container.end(), item), item);
// }

// // Function to remove an element from the container at the specified position
// template <typename T>
// void remove_element(T& container, int position) {
//     auto it = container.begin();
//     advance(it, position);
//     container.erase(it);
// }

// // Function to generate N random integers without replacement
// vector<LargeStruct> generate_random_integers(int N) {
//     vector<LargeStruct> nums(N);
//     for (int i = 0; i < N; ++i) {
//         for (int j = 0; j < 100; ++j) {
//             nums[i].value = i * 100 + j + 1;
//         }
//     }
//     unsigned seed = chrono::system_clock::now().time_since_epoch().count();
//     shuffle(nums.begin(), nums.end(), default_random_engine(seed));
//     return nums;
// }

// int main() {
//     int N = 300000; // The number of random integers to generate and insert
//     auto nums = generate_random_integers(N);

//     // Record the start time for insertion
//     auto start_insertion = chrono::high_resolution_clock::now();

//     // Experiment with std::list
//     list<LargeStruct> sequence_list;
//     sequence_list.resize(N); // Pre-allocate elements

//     // Copy elements from nums to sequence_list
//     copy(nums.begin(), nums.end(), sequence_list.begin());

//     // Sort the list using std::list::sort()
//     sequence_list.sort();

//     // Record the end time for insertion
//     auto end_insertion = chrono::high_resolution_clock::now();

//     // Record the start time for removal
//     auto start_removal = chrono::high_resolution_clock::now();

//     // Remove elements from the list at random positions
//     for (int i = 0; i < N; ++i) {
//         if (!sequence_list.empty()) {
//             int position = rand() % sequence_list.size();
//             auto it = sequence_list.begin();
//             advance(it, position);
//             sequence_list.erase(it);
//         }
//     }

//     // Record the end time for removal
//     auto end_removal = chrono::high_resolution_clock::now();

//     // Calculate and print the time taken for insertion and removal
//     auto insertion_time_list = chrono::duration_cast<chrono::milliseconds>(end_insertion - start_insertion).count();
//     auto removal_time_list = chrono::duration_cast<chrono::milliseconds>(end_removal - start_removal).count();

//     cout << "List Insertion time: " << insertion_time_list << " milliseconds" << endl;
//     cout << "List Removal time: " << removal_time_list << " milliseconds" << endl;

//     // ... (continue with std::vector and std::set as before)

//     return 0;
// }



// #include <iostream>
// #include <list>
// #include <vector>
// #include <set>
// #include <algorithm>
// #include <random>
// #include <chrono>

// using namespace std;

// struct LargeStruct {
//     int value;
//     // other members of LargeStruct

//     // Define the less-than operator for LargeStruct
//     bool operator<(const LargeStruct& other) const {
//         return value < other.value;
//     }
// };

// // Function to perform insertion sort and insert the element in the correct position
// template <typename T>
// void insertion_sort(T& container, const LargeStruct& item) {
//     container.insert(lower_bound(container.begin(), container.end(), item), item);
// }

// // Function to remove an element from the container at the specified position
// template <typename T>
// void remove_element(T& container, int position) {
//     auto it = container.begin();
//     advance(it, position);
//     container.erase(it);
// }

// // Function to generate N random integers without replacement
// vector<LargeStruct> generate_random_integers(int N) {
//     vector<LargeStruct> nums(N);
//     for (int i = 0; i < N; ++i) {
//         for (int j = 0; j < 100; ++j) {
//             nums[i].value = i * 100 + j + 1;
//         }
//     }
//     unsigned seed = chrono::system_clock::now().time_since_epoch().count();
//     shuffle(nums.begin(), nums.end(), default_random_engine(seed));
//     return nums;
// }

// int main() {
//     int N = 300000; // The number of random integers to generate and insert
//     auto nums = generate_random_integers(N);

//     // Record the start time for insertion
//     auto start_insertion = chrono::high_resolution_clock::now();

//     // Experiment with std::vector
//     vector<LargeStruct> sequence_vector;
//     sequence_vector.reserve(N); // Pre-allocate memory for elements
//     for (const auto& item : nums) {
//         insertion_sort(sequence_vector, item);
//     }

//     // Record the end time for insertion
//     auto end_insertion = chrono::high_resolution_clock::now();

//     // Record the start time for removal
//     auto start_removal = chrono::high_resolution_clock::now();

//     // Remove elements from the vector at random positions
//     for (int i = 0; i < N; ++i) {
//         int position = rand() % sequence_vector.size();
//         remove_element(sequence_vector, position);
//     }

//     // Record the end time for removal
//     auto end_removal = chrono::high_resolution_clock::now();

//     // Calculate and print the time taken for insertion and removal
//     auto insertion_time_vector = chrono::duration_cast<chrono::milliseconds>(end_insertion - start_insertion).count();
//     auto removal_time_vector = chrono::duration_cast<chrono::milliseconds>(end_removal - start_removal).count();

//     cout << "Vector Insertion time: " << insertion_time_vector << " milliseconds" << endl;
//     cout << "Vector Removal time: " << removal_time_vector << " milliseconds" << endl;

//     // ... (continue with std::list and std::set as before)

//     return 0;
// }
