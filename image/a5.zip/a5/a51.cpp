//g++ -std=c++20 -o runProgram a5/a51.cpp

#include <iostream>
#include <vector>
#include <stdexcept>
#include <type_traits>

template <typename T>
concept Integral = std::is_integral_v<T>;

template <typename T>
class Imatrix {
public:
    // Default constructor
    Imatrix() : rows(0), cols(0), data(0) {}

    // Constructor with specified size
    Imatrix(int rows, int cols) : rows(rows), cols(cols), data(rows * cols, T{}) {}

    // Copy constructor
    Imatrix(const Imatrix& other) : rows(other.rows), cols(other.cols), data(other.data) {}

    // Move constructor
    Imatrix(Imatrix&& other) noexcept : rows(other.rows), cols(other.cols), data(std::move(other.data)) {
        other.rows = other.cols = 0;
    }

    // Destructor
    ~Imatrix() {}

    // Assignment operator
    Imatrix& operator=(const Imatrix& other) {
        if (this != &other) {
            rows = other.rows;
            cols = other.cols;
            data = other.data;
        }
        return *this;
    }

    // Move assignment operator
    Imatrix& operator=(Imatrix&& other) noexcept {
        if (this != &other) {
            rows = other.rows;
            cols = other.cols;
            data = std::move(other.data);
            other.rows = other.cols = 0;
        }
        return *this;
    }

    // Subscripting operator
    T& operator()(int x, int y) {
        if (x < 0 || x >= rows || y < 0 || y >= cols) {
            throw std::out_of_range("Matrix index is not in range.");
        }
        return data[x * cols + y];
    }

    // Addition operator (for integral types)
    template <typename U = T>
    requires Integral<U>
    Imatrix operator+(const Imatrix& other) const {
        if (rows != other.rows || cols != other.cols) {
            throw std::invalid_argument("Matrix dimensions does not match for addition.");
        }

        Imatrix result(rows, cols);
        for (int i = 0; i < rows * cols; i++) {
            result.data[i] = data[i] + other.data[i];
        }
        return result;
    }

    // Subtraction operator (for integral types)
    template <typename U = T>
    requires Integral<U>
    Imatrix operator-(const Imatrix& other) const {
        if (rows != other.rows || cols != other.cols) {
            throw std::invalid_argument("Matrix dimensions does not match  for subtraction.");
        }

        Imatrix result(rows, cols);
        for (int i = 0; i < rows * cols; i++) {
            result.data[i] = data[i] - other.data[i];
        }
        return result;
    }

    // Multiplication operator (for integral types)
    template <typename U = T>
    requires Integral<U>
    Imatrix operator*(const Imatrix& other) const {
        if (cols != other.rows) {
            throw std::invalid_argument("Matrix dimensions does not match  for multiplication.");
        }

        Imatrix result(rows, other.cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < other.cols; j++) {
                U sum = 0;
                for (int k = 0; k < cols; k++) {
                    sum += data[i * cols + k] * other.data[k * other.cols + j];
                }
                result.data[i * other.cols + j] = sum;
            }
        }
        return result;
    }


    // Modulo operator (for integral types)
    template <typename U = T>
    requires Integral<U>
    Imatrix operator%(U mod) const {
        if (mod == 0) {
            throw std::invalid_argument("Modulo by zero.");
        }

        Imatrix result(rows, cols);
        for (int i = 0; i < rows * cols; i++) {
            result.data[i] = data[i] % mod;
        }
        return result;
    }

        // Division operator (for integral types)
    template <typename U = T>
    requires Integral<U>
    Imatrix operator/(U divisor) const {
        if (divisor == 0) {
            throw std::invalid_argument("Division by zero.");
        }

        Imatrix result(rows, cols);
        for (int i = 0; i < rows * cols; i++) {
            result.data[i] = data[i] / divisor;
        }
        return result;
    }


    // Move function
    void Move(int x, int y) {
        if (x < 0 || x >= rows || y < 0 || y >= cols) {
            throw std::out_of_range("Matrix index not in range.");
        }
        std::swap(data[x * cols + y], data[y * cols + x]);
        data[x * cols + y] = T{};
    }

    // Get row function
    std::vector<T> Row(int n) const {
        if (n < 0 || n >= rows) {
            throw std::out_of_range("Matrix row index not in range.");
        }
        std::vector<T> row(cols);
        for (int i = 0; i < cols; i++) {
            row[i] = data[n * cols + i];
        }
        return row;
    }

    // Get column function
    std::vector<T> Column(int n) const {
        if (n < 0 || n >= cols) {
            throw std::out_of_range("Matrix column index not in range.");
        }
        std::vector<T> col(rows);
        for (int i = 0; i < rows; i++) {
            col[i] = data[i * cols + n];
        }
        return col;
    }

private:
    int rows;
    int cols;
    std::vector<T> data;
};

int main() {
    try {
        Imatrix<int> matrix1(3, 3);
        matrix1(0, 0) = 1;
        matrix1(0, 1) = 2;
        matrix1(0, 2) = 3;
        matrix1(1, 0) = 4;
        matrix1(1, 1) = 5;
        matrix1(1, 2) = 6;
        matrix1(2, 0) = 7;
        matrix1(2, 1) = 8;
        matrix1(2, 2) = 9;

        Imatrix<int> matrix2(3, 3);
        matrix2(0, 0) = 9;
        matrix2(0, 1) = 8;
        matrix2(0, 2) = 7;
        matrix2(1, 0) = 6;
        matrix2(1, 1) = 5;
        matrix2(1, 2) = 4;
        matrix2(2, 0) = 3;
        matrix2(2, 1) = 2;
        matrix2(2, 2) = 1;

        // Perform operations
        Imatrix<int> result_add = matrix1 + matrix2;
        Imatrix<int> result_sub = matrix1 - matrix2;
        Imatrix<int> result_mul = matrix1 * matrix2;
        Imatrix<int> result_div = matrix1 / 2;
        Imatrix<int> result_mod = matrix1 % 3;

        // Display the results
        std::cout << "Matrix 1:\n";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                std::cout << matrix1(i, j) << " ";
            }
            std::cout << "\n";
        }

        std::cout << "\nMatrix 2:\n";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                std::cout << matrix2(i, j) << " ";
            }
            std::cout << "\n";
        }

        std::cout << "\nResult of addition:\n";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                std::cout << result_add(i, j) << " ";
            }
            std::cout << "\n";
        }

        std::cout << "\nResult of subtraction:\n";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                std::cout << result_sub(i, j) << " ";
            }
            std::cout << "\n";
        }

        std::cout << "\nResult of multiplication:\n";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                std::cout << result_mul(i, j) << " ";
            }
            std::cout << "\n";
        }

    
        std::cout << "\nResult of modulo:\n";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                std::cout << result_mod(i, j) << " ";
            }
            std::cout << "\n";
        }

        std::cout << "\nResult of division:\n";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                std::cout << result_div(i, j) << " ";
            }
            std::cout << "\n";
        }

    }
    catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
