//g++ -std=c++20 -o runProgram a5/a5_experiments.cpp


#include <iostream>
#include <vector>
#include <stdexcept>
#include <type_traits>
#include <chrono> // For measuring time

//a concept to constrain T to arithmetic typer (integral and floating point)

template <typename T>
concept Arithmetic = std::is_arithmetic_v<T>;

template <typename T>
class Imatrix {
public:
    // Default constructor
    Imatrix() : rows(0), cols(0), data(0) {}

    // Constructor with specified size
    Imatrix(int rows, int cols) : rows(rows), cols(cols), data(rows * cols, T{}) {}

    // Copy constructor
    Imatrix(const Imatrix& other) : rows(other.rows), cols(other.cols), data(other.data) {}

    // Move constructor
    Imatrix(Imatrix&& other) noexcept : rows(other.rows), cols(other.cols), data(std::move(other.data)) {
        other.rows = other.cols = 0;
    }

    // Destructor
    ~Imatrix() {}

    // Assignment operator
    Imatrix& operator=(const Imatrix& other) {
        if (this != &other) {
            rows = other.rows;
            cols = other.cols;
            data = other.data;
        }
        return *this;
    }

    // Move assignment operator
    Imatrix& operator=(Imatrix&& other) noexcept {
        if (this != &other) {
            rows = other.rows;
            cols = other.cols;
            data = std::move(other.data);
            other.rows = other.cols = 0;
        }
        return *this;
    }

    // Subscripting operator
    T& operator()(int x, int y) {
        if (x < 0 || x >= rows || y < 0 || y >= cols) {
            throw std::out_of_range("Matrix index out of range.");
        }
        return data[x * cols + y];
    }

    // Addition operator (for arithmetic types)
    template <typename U = T>
    requires Arithmetic<U>
    Imatrix operator+(const Imatrix& other) const {
        if (rows != other.rows || cols != other.cols) {
            throw std::invalid_argument("Matrix dimensions mismatch for addition.");
        }

        Imatrix result(rows, cols);
        for (int i = 0; i < rows * cols; i++) {
            result.data[i] = data[i] + other.data[i];
        }
        return result;
    }

    // Multiplication operator (for arithmetic types)
    template <typename U = T>
    requires Arithmetic<U>
    Imatrix operator*(const Imatrix& other) const {
        if (cols != other.rows) {
            throw std::invalid_argument("Matrix dimensions mismatch for multiplication.");
        }

        Imatrix result(rows, other.cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < other.cols; j++) {
                U sum = 0;
                for (int k = 0; k < cols; k++) {
                    sum += data[i * cols + k] * other.data[k * other.cols + j];
                }
                result.data[i * other.cols + j] = sum;
            }
        }
        return result;
    }

private:
    int rows;
    int cols;
    std::vector<T> data;
};

int main() {
    try {
        // Experiment 1: Testing Non-Integral Types
        Imatrix<double> matrix3(3, 3);
        matrix3(0, 0) = 1.1;
        matrix3(0, 1) = 2.2;
        matrix3(0, 2) = 3.3;
        matrix3(1, 0) = 4.4;
        matrix3(1, 1) = 5.5;
        matrix3(1, 2) = 6.6;
        matrix3(2, 0) = 7.7;
        matrix3(2, 1) = 8.8;
        matrix3(2, 2) = 9.9;

        Imatrix<double> result_double_add = matrix3 + matrix3;

        std::cout << "Matrix 3:\n";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                std::cout << matrix3(i, j) << " ";
            }
            std::cout << "\n";
        }

        std::cout << "\nResult of double addition:\n";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                std::cout << result_double_add(i, j) << " ";
            }
            std::cout << "\n";
        }

        // Experiment 2: Performance Testing
        const int largeSize = 1000;
        Imatrix<int> large_matrix1(largeSize, largeSize);
        Imatrix<int> large_matrix2(largeSize, largeSize);

        auto start = std::chrono::high_resolution_clock::now();
        Imatrix<int> result_large_mul = large_matrix1 * large_matrix2;
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> duration = end - start;
        std::cout << "\nMatrix multiplication took " << duration.count() << " seconds.\n";

    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
