//g++ -std=c++20 -o runProgram a5/a52.cpp


#include <iostream>
#include <vector>
#include <stdexcept>
#include <concepts> // Use concepts

// Minimal Chess_piece type
struct Chess_piece {
    std::string name;
    int strength;
};

// Generic Matrix class
template <typename T>
class Matrix {
public:
    // Constructors
    Matrix() : data_(), rows_(0), cols_(0) {}
    Matrix(size_t rows, size_t cols) : data_(rows * cols, T{}), rows_(rows), cols_(cols) {}

    // Copy and move constructors
    Matrix(const Matrix& other) = default;
    Matrix(Matrix&& other) noexcept = default;
    Matrix& operator=(const Matrix& other) = default;
    Matrix& operator=(Matrix&& other) noexcept = default;

    // Subscripting operator
    T& operator()(size_t x, size_t y) {
        if (x >= rows_ || y >= cols_) {
            throw std::out_of_range("Matrix subscript is not in range");
        }
        return data_[x * cols_ + y];
    }

    const T& operator()(size_t x, size_t y) const {
        if (x >= rows_ || y >= cols_) {
            throw std::out_of_range("Matrix subscript is not in range");
        }
        return data_[x * cols_ + y];
    }

    // Addition, multiplication, division, and subtraction
    Matrix operator+(const Matrix& other) const {
        if (rows_ != other.rows_ || cols_ != other.cols_) {
            throw std::invalid_argument("Matrix dimensions does not match");
        }

        Matrix result(rows_, cols_);
        for (size_t i = 0; i < rows_ * cols_; ++i) {
            result.data_[i] = data_[i] + other.data_[i];
        }
        return result;
    }

    Matrix operator*(const Matrix& other) const {
        if (cols_ != other.rows_) {
            throw std::invalid_argument("Matrix dimensions does not match");
        }

        Matrix result(rows_, other.cols_);
        for (size_t i = 0; i < rows_; ++i) {
            for (size_t j = 0; j < other.cols_; ++j) {
                for (size_t k = 0; k < cols_; ++k) {
                    result.data_[i * other.cols_ + j] += data_[i * cols_ + k] * other.data_[k * other.cols_ + j];
                }
            }
        }
        return result;
    }

    Matrix operator/(const Matrix& other) const {
        if (cols_ != other.cols_ || rows_ != other.rows_) {
            throw std::invalid_argument("Matrix dimensions does not match");
        }

        Matrix result(rows_, cols_);
        for (size_t i = 0; i < rows_ * cols_; ++i) {
            result.data_[i] = data_[i] / other.data_[i];
        }
        return result;
    }

    Matrix operator-(const Matrix& other) const {
        if (rows_ != other.rows_ || cols_ != other.cols_) {
            throw std::invalid_argument("Matrix dimensions does not match");
        }

        Matrix result(rows_, cols_);
        for (size_t i = 0; i < rows_ * cols_; ++i) {
            result.data_[i] = data_[i] - other.data_[i];
        }
        return result;
    }

    // Modulo operator (%) defined for elements that support it (e.g., integers)
    template <typename U = T>
    requires std::is_integral_v<U>
    Matrix operator%(const Matrix& other) const {
        if (cols_ != other.cols_ || rows_ != other.rows_) {
            throw std::invalid_argument("Matrix dimensions does not match");
        }

        Matrix result(rows_, cols_);
        for (size_t i = 0; i < rows_ * cols_; ++i) {
            result.data_[i] = data_[i] % other.data_[i];
        }
        return result;
    }

    // Move operation: move value from location x to location y and leave x in the default state
    void move(size_t from_x, size_t from_y, size_t to_x, size_t to_y) {
        if (from_x >= rows_ || from_y >= cols_ || to_x >= rows_ || to_y >= cols_) {
            throw std::out_of_range("Matrix move operation not in range range");
        }

        data_[to_x * cols_ + to_y] = std::move(data_[from_x * cols_ + from_y]);
        data_[from_x * cols_ + from_y] = T{};
    }

private:
    std::vector<T> data_;
    size_t rows_;
    size_t cols_;
};

int main() {
    // Test Matrix<int>
    Matrix<int> matrix1(2, 2);
    matrix1(0, 0) = 1;
    matrix1(0, 1) = 2;
    matrix1(1, 0) = 3;
    matrix1(1, 1) = 4;

    Matrix<int> matrix2(2, 2);
    matrix2(0, 0) = 5;
    matrix2(0, 1) = 6;
    matrix2(1, 0) = 7;
    matrix2(1, 1) = 8;

    Matrix<int> matrix3 = matrix1 + matrix2;
    std::cout << "Matrix1 + Matrix2:" << std::endl;
    for (size_t i = 0; i < 2; ++i) {
        for (size_t j = 0; j < 2; ++j) {
            std::cout << matrix3(i, j) << " ";
        }
        std::cout << std::endl;
    }

    // Test Matrix   <std::string>
    Matrix<std::string> strMatrix(2, 2);
    strMatrix(0, 0) = "Hello";
    strMatrix(0, 1) = "World";
    strMatrix(1, 0) = "C++: A5";
    strMatrix(1, 1) = "Matrix Works";

    std::cout << "\nMatrix<std::string>:" << std::endl;
    for (size_t i = 0; i < 2; ++i) {
        for (size_t j = 0; j < 2; ++j) {
            std::cout << strMatrix(i, j) << " ";
        }
        std::cout << std::endl;
    }

    // Test Matrix<Chess_piece>
    Matrix<Chess_piece> chessMatrix(2, 2);
    chessMatrix(0, 0) = { "Rook", 5 };
    chessMatrix(0, 1) = { "Pawn", 3 };
    chessMatrix(1, 0) = { "Knight", 3 };
    chessMatrix(1, 1) = { "Queen", 9 };

    std::cout << "\nMatrix<Chess_piece>:" << std::endl;
    for (size_t i = 0; i < 2; ++i) {
        for (size_t j = 0; j < 2; ++j) {
            std::cout << chessMatrix(i, j).name << " (" << chessMatrix(i, j).strength << ") ";
        }
        std::cout << std::endl;
    }

    return 0;
}
