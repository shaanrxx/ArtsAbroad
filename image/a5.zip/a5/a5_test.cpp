//g++ -std=c++20 -o runProgram a5/a5_test.cpp
#include <iostream>

template <class T>
class Matrix
{
private:
    int rows, cols;
    T* pMatrix;

public:
    // Constructors
    Matrix(int Rows, int Cols)
    {
        rows = Rows;
        cols = Cols;
        pMatrix = new T[rows * cols];
    }

    Matrix(int Size)
    {
        rows = Size;
        cols = Size;
        pMatrix = new T[rows * cols];
    }

    // Getter methods for rows and cols
    int getRows() const { return rows; }
    int getCols() const { return cols; }

    // Copy constructor and destructor
    Matrix(const Matrix& matrix)
    {
        rows = matrix.rows;
        cols = matrix.cols;
        pMatrix = new T[rows * cols];
        for (int i = 0; i < rows * cols; i++)
        {
            pMatrix[i] = matrix.pMatrix[i];
        }
    }

    ~Matrix()
    {
        delete[] pMatrix;
    }

    // Friend function to input matrix elements
    friend std::istream& operator>> <> (std::istream& s, Matrix& matrix);

    // Friend function to output matrix elements
    friend std::ostream& operator<< <> (std::ostream& s, const Matrix& matrix);
};

// Definition of the friend function for input
template <typename T>
std::istream& operator>>(std::istream& s, Matrix<T>& matrix)
{
    for (int i = 0; i < matrix.rows * matrix.cols; i++)
    {
        s >> matrix.pMatrix[i];
    }
    return s;
}

// Definition of the friend function for output
template <typename T>
std::ostream& operator<<(std::ostream& s, const Matrix<T>& matrix)
{
    for (int i = 0; i < matrix.rows; i++)
    {
        for (int j = 0; j < matrix.cols; j++)
        {
            s << matrix.pMatrix[i * matrix.cols + j] << " ";
        }
        s << std::endl;
    }
    return s;
}

int main()
{
    // Create a matrix of integers with 2 rows and 3 columns
    Matrix<int> A(2, 3);

    // Input matrix elements for A
    std::cout << "Enter " << A.getRows() * A.getCols() << " integer values for matrix A:" << std::endl;
    std::cin >> A;

    // Output matrix elements for A
    std::cout << "Matrix A:" << std::endl;
    std::cout << A;

    return 0;
}
