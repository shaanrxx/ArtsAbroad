//g++ -std=c++20 -o runProgram a2/a221.cpp

#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>

int main() {
    // Create a large vector of integers with elements ≥ 7
    const int vectorSize = 10000000;
    std::vector<int> myVector;

    for (int i = 0; i < vectorSize; ++i) {
        myVector.push_back(7 + i); // All elements are ≥ 7
    }

    // Insert x in the middle of the vector where x < 7
    int middleIndex = myVector.size() / 2;
    myVector[middleIndex] = 6;

    // Measure the time taken to find x < 7 in the middle of the vector
    auto startTime = std::chrono::high_resolution_clock::now();
    auto result = std::find_if(myVector.begin(), myVector.end(), [](int value) { return value < 7; });
    auto endTime = std::chrono::high_resolution_clock::now();

    if (result != myVector.end()) {
        std::cout << "Element " << *result << " found at index: " << std::distance(myVector.begin(), result) << std::endl;
    } else {
        std::cout << "No element less than 7 found in the middle of the vector." << std::endl;
    }

    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime);
    std::cout << "Time taken: " << duration.count() << " microseconds" << std::endl;

    return 0;
}
