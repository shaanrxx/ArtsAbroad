//g++ -std=c++20 -o runProgram a2/a232.cpp

#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <random>

std::string generate_random_string(int length) {
    static const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static std::mt19937 generator(std::random_device{}());
    static std::uniform_int_distribution<> distribution(0, sizeof(charset) - 2);

    std::string result;
    for (int i = 0; i < length; ++i) {
        result += charset[distribution(generator)];
    }
    return result;
}

int main() {
    // Generate a vector of 1,000,000 random 20-letter strings
    const int dataSize = 1000000;
    const int stringLength = 20;
    std::vector<std::string> data;
    data.reserve(dataSize);
    for (int i = 0; i < dataSize; ++i) {
        data.push_back(generate_random_string(stringLength));
    }

    // Place "XXXXXXXXXXXXXXXXXXXX" in the middle of the vector
    std::string specialValue = "XXXXXXXXXXXXXXXXXXXX";
    size_t middleIndex = data.size() / 2;
    data[middleIndex] = specialValue;

    // Find "XXXXXXXXXXXXXXXXXXXX" using std::find()
    auto startTime = std::chrono::high_resolution_clock::now();
    auto it = std::find(data.begin(), data.end(), specialValue);
    auto endTime = std::chrono::high_resolution_clock::now();

    // Check if the value was found
    bool found = (it != data.end());

    // Output the result and performance
    std::cout << "Value found: " << std::boolalpha << found << std::endl;
    if (found) {
        std::cout << "Value found at index: " << std::distance(data.begin(), it) << std::endl;
    }

    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime).count();
    std::cout << "Execution time: " << duration << " microseconds" << std::endl;

    return 0;
}