//g++ -std=c++20 -o runProgram a2/a211.cpp

#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>

int main() {
    // Create a vector of integers with 10 million elements (large enough for meaningful values)
    const int vectorSize = 10000000;
    std::vector<int> myVector;

    for (int i = 0; i < vectorSize; ++i) {
        myVector.push_back(5); // All elements are not 7
    }

    // Insert 7 in the middle of the vector
    int middleIndex = myVector.size() / 2;
    myVector[middleIndex] = 7;

    // Measure the time taken to find the element 7
    int elementToFind = 7;
    auto startTime = std::chrono::high_resolution_clock::now();
    auto result = std::find(myVector.begin(), myVector.end(), elementToFind);
    auto endTime = std::chrono::high_resolution_clock::now();

    if (result != myVector.end()) {
        std::cout << "Element " << elementToFind << " found at index: " << std::distance(myVector.begin(), result) << std::endl;
    } else {
        std::cout << "Element " << elementToFind << " not found in the vector." << std::endl;
    }

    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime);
    std::cout << "Time taken: " << duration.count() << " microseconds" << std::endl;

    // Create another vector with no element as 7
    std::vector<int> myOtherVector(vectorSize, 5); // Initialize with all elements as 5 (not 7)

    // Try to find 7 in the vector where no element is 7
    startTime = std::chrono::high_resolution_clock::now();
    result = std::find(myOtherVector.begin(), myOtherVector.end(), elementToFind);
    endTime = std::chrono::high_resolution_clock::now();

    if (result != myOtherVector.end()) {
        std::cout << "Element " << elementToFind << " found at index: " << std::distance(myOtherVector.begin(), result) << std::endl;
    } else {
        std::cout << "Element " << elementToFind << " not found in the vector." << std::endl;
    }

    duration = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime);
    std::cout << "Time taken: " << duration.count() << " microseconds" << std::endl;

    return 0;
}
