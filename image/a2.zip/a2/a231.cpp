
//g++ -std=c++20 -o runProgram a2/a231.cpp

#include <iostream>     // enables input and output streams 
#include <vector>
#include <algorithm>
#include <random>    //generate random numbers
#include <chrono>    // time taken to measure string uses chrono library

// Function to generate a random 20-letter string
std::string genRandomString() {
    //characters that can generate random string

    // std::default_random_engine - random number engine provided by  C++ standard library
    // std::chrono::high_resolution_clock::now().time_since_epoch().count() provides a random seed based on the current time
    // makes sure each time the function is called it will use a different random seed
    const std::string charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
     // defines distribution for generating random indices within range of string charset - each cahracter has equal probability
    // range is from 0 to size of the charset - 1 as string indices are 0-based
    std::default_random_engine rng(std::chrono::high_resolution_clock::now().time_since_epoch().count());
    std::uniform_int_distribution<size_t> distribution(0, charset.size() - 1);

    std::string randomString;   // string that holds the random characters
    for (int i = 0; i < 20; ++i) {
        randomString.push_back(charset[distribution(rng)]);
    }

// Return the final random string of length 20.
    return randomString;
}



int main() {
    // Create a vector of 1,000,000 random 20-letter strings
    const int vectorSize = 1000000;
    std::vector<std::string> myVector;

    // Generate and add 1,000,000 random 20-letter strings to the vector
    for (int i = 0; i < vectorSize; ++i) {
        myVector.push_back(genRandomString());
    }

    // Try to find "XXXXXXXXXXXXXXXXXXXX" in the vector
    std::string searchString = "XXXXXXXXXXXXXXXXXXXX";
    auto startTime = std::chrono::high_resolution_clock::now();    // Measure the start time before searching
    auto result = std::find(myVector.begin(), myVector.end(), searchString);    // Try to find the searchString in the vector using std::find()
    auto endTime = std::chrono::high_resolution_clock::now();    // Measure the end time after searching

    if (result != myVector.end()) {      // Check if the searchString was found and display the result
        std::cout << "Element " << searchString << " found at index: " << std::distance(myVector.begin(), result) << std::endl;
    } else {
        std::cout << "Element " << searchString << " not found in the vector." << std::endl;
    }

    // Calculate the duration of the search and display it in microseconds
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime);
    std::cout << "Time taken: " << duration.count() << " microseconds" << std::endl;

    return 0;
}
