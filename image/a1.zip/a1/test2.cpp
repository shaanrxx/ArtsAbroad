#include <iostream>
#include <string_view>
#include <ranges>

int main() {
    std::string_view greeting = "Hello, World";
    auto firstFiveLetters = greeting | std::views::take(5);

    for (char letter : firstFiveLetters) {
        std::cout << letter;
    }
    std::cout << std::endl;

    return 0;
}


